from flask import Flask, render_template, request, redirect, url_for, session
import random

app = Flask(__name__)
app.secret_key = 'secret'  # Required for session management

@app.route('/', methods=['GET', 'POST'])
def index():
    if request.method == 'POST':
        session['name'] = request.form['name']
        session['number'] = random.randint(1, 100)
        session['attempts'] = 0
        return redirect(url_for('game'))
    return render_template('index.html')

@app.route('/game', methods=['GET', 'POST'])
def game():
    message = ""
    if request.method == 'POST':
        guess = int(request.form['guess'])
        session['attempts'] += 1
        if guess < session['number']:
            message = "📈 Too low! Try a higher number."
        elif guess > session['number']:
            message = "📉 Too high! Try a lower number."
        else:
            return redirect(url_for('certificate'))
    return render_template('game.html', message=message, attempts=session['attempts'], name=session['name'])

@app.route('/certificate')
def certificate():
    return render_template('certificate.html', name=session['name'], attempts=session['attempts'])

if __name__ == "__main__":
    app.run(debug=True)
